import java.awt.*;
import javax.swing.*;

public class MainFrame extends JFrame {
    public MainFrame(){
        setTitle("BMICalculator");
        setSize(800, 600);

         JPanel welcomePanel = new JPanel();
         JLabel titleLable= new JLabel("Welcome to BMI Calculator");
         JLabel NameLable= new JLabel("Enter Your Name:");
         JTextField NameField= new JTextField(15);
         JButton startButton= new JButton("Start");

         welcomePanel.add(titleLable);

         welcomePanel.setLayout(new GridLayout(3,1));
         welcomePanel.add(NameLable);
         welcomePanel.add(NameField);
         welcomePanel.add(startButton);

         add(welcomePanel);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(()->{
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}

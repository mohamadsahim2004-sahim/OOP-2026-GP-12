import javax.swing.*;

public class WelcomeForm {
    private JTextField nameField;
    private JButton startButton;
    private JLabel titleLabel;
    private JLabel nameLabel;
    private JPanel panel1;


    public WelcomeForm(){
        startButton.addActionListener((e ->{
            String name = nameField.getText().trim();
            if(name.isEmpty()){
                JOptionPane.showMessageDialog(panel1, "Please enter a name!");
                return;
            }
            SwingUtilities.getWindowAncestor(panel1).dispose();
            new CalculateFrame(name).setVisible(true);

        }));
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("BMI Calculator");
        frame.setContentPane(new  WelcomeForm().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

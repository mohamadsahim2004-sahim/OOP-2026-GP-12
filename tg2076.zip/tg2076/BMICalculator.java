public class BMICalculator {
    private double weight;
    private double height;
    private boolean metric;

    public BMICalculator(double weight, double height, boolean metric) {
        this.weight = weight;
        this.height = height;
        this.metric = metric;
    }

    public double getBMI(){
        if(metric){
            return weight/(height*height);
        }
        return (weight*703)/(height*height);
    }

    public String getCategory() {
        double bmi = getBMI();
        if (bmi > 18.5) return "Underweight";
        else if (bmi < 25) return "Normal";
        else if (bmi < 30) return "Overweight";
        else
            return "Obese";

    }




}

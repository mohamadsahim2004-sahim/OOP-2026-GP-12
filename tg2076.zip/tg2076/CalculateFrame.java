import  javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class CalculateFrame extends JFrame {
    public CalculateFrame(String name) {
        setTitle("BMI Calculator");
        setSize(500,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);


        JTextField weightField=new JTextField(10);
        JTextField heightField=new JTextField(10);
        JRadioButton metricBtn=new JRadioButton("Metric (kg,m)",true);
        JRadioButton englishBtn =new JRadioButton("English(lb, in)");
        ButtonGroup group = new ButtonGroup();
        group.add(metricBtn);
        group.add(englishBtn);
        JButton calcBtn=new JButton("Calculate");
        JLabel resultLabel=new JLabel(" ");
        JLabel categoryLabel=new JLabel(" ");

        JTextArea table =new JTextArea(
                "BMI Values\n" +
                        "Underweight: less than 18.5\n" +
                        "Normal: between 18.5 and 24.9\n" +
                        "Overweight: between 25 and 29.9\n" +
                        "Obese: 30 or grater");
        table.setEditable(false);

        JPanel panel=new JPanel(new GridLayout(0,1,5,5));
        panel.setBorder(BorderFactory.createEmptyBorder(15,15,15,15));
        panel.add(new JLabel("To calculate your BMI..:"));
        panel.add(metricBtn);
        panel.add(englishBtn);
        panel.add(new JLabel("Enter your weight"));
        panel.add(weightField);
        panel.add(new JLabel("Enter your height"));
        panel.add(heightField);
        panel.add(calcBtn);
        panel.add(resultLabel);
        panel.add(categoryLabel);
        panel.add(table);
        add(panel);

        calcBtn.addActionListener(e -> {
            try {
                double w = Double.parseDouble(weightField.getText().trim());
                double h = Double.parseDouble(heightField.getText().trim());
                if(w <= 0 || h <= 0){
                    throw new NumberFormatException();

                }
                BMICalculator calc = new BMICalculator(w,h,metricBtn.isSelected());
                resultLabel.setText(name + "Your BMI is: " + String.format("%.1f",calc.getBMI()));
                categoryLabel.setText("category: " + calc.getCategory());


            }
            catch(NumberFormatException ex){
                resultLabel.setText("Please enter a valid positive number");
                categoryLabel.setText(" ");
            }
                }

        );




    }
}
